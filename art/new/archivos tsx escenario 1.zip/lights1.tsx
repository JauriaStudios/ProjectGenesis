<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="lights1" tilewidth="16" tileheight="16" tilecount="12" columns="3">
 <image source="../envio/lights1.png" width="55" height="68"/>
</tileset>
