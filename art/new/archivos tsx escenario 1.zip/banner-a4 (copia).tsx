<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="banner-a4" tilewidth="16" tileheight="16" tilecount="15" columns="5">
 <image source="Z:/home/izzy/Descargas/stage city/cyberpunk city 2 files/Environmet/props/banner-a/banner-a4.png" width="90" height="60"/>
</tileset>
