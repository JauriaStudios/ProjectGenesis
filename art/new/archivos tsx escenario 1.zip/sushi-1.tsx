<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="sushi-1" tilewidth="16" tileheight="16" tilecount="3" columns="1">
 <image source="Z:/home/izzy/Descargas/stage city/Streets of Fight files/Stage Layers/props/Sushi/sushi-1.png" width="18" height="48"/>
</tileset>
