<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="near-buildings-bg" tilewidth="16" tileheight="16" tilecount="390" columns="30">
 <image source="Z:/home/izzy/Descargas/stage city/warped_city_files/warped city files/ENVIRONMENT/background/near-buildings-bg.png" width="493" height="209"/>
</tileset>
