<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="barrel" tilewidth="16" tileheight="16" tilecount="12" columns="4">
 <image source="Z:/home/izzy/Descargas/stage city/Streets of Fight files/Stage Layers/props/barrel.png" width="64" height="48"/>
</tileset>
