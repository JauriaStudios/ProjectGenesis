<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="CIudad" tilewidth="32" tileheight="32" tilecount="204" columns="17">
 <image source="Z:/home/izzy/Descargas/stage city/Streets of Fight files/Stage Layers/tileset.png" width="544" height="384"/>
</tileset>
