<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="banner-c1" tilewidth="16" tileheight="16" tilecount="12" columns="3">
 <image source="../envio/banner-c1.png" width="54" height="65"/>
</tileset>
