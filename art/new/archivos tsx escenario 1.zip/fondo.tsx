<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fondo" tilewidth="16" tileheight="16" tilecount="30" columns="6">
 <image source="Z:/home/izzy/Descargas/stage city/Streets of Fight files/Stage Layers/back.png" width="96" height="80"/>
</tileset>
