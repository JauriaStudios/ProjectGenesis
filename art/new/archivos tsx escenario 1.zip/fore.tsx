<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fore" tilewidth="16" tileheight="16" tilecount="108" columns="12">
 <image source="Z:/home/izzy/Descargas/stage city/Streets of Fight files/Stage Layers/fore.png" width="192" height="144"/>
</tileset>
