<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="buildings-bg" tilewidth="16" tileheight="16" tilecount="63" columns="9">
 <image source="Z:/home/izzy/Descargas/stage city/warped_city_files/warped city files/ENVIRONMENT/background/buildings-bg.png" width="144" height="124"/>
</tileset>
